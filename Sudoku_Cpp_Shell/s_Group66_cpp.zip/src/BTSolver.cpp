#include"BTSolver.hpp"
#include <algorithm>     
#include <unordered_map> 
#include <unordered_set> 
#include <queue> 
#include <climits>        
using namespace std;

// =====================================================================
// Constructors
// =====================================================================

BTSolver::BTSolver ( SudokuBoard input, Trail* _trail,  string val_sh, string var_sh, string cc )
: sudokuGrid( input.get_p(), input.get_q(), input.get_board() ), network( input )
{
	valHeuristics = val_sh;
	varHeuristics = var_sh; 
	cChecks =  cc;

	trail = _trail;
	buildNeighborCache();
}

void BTSolver::buildNeighborCache()
{
	unordered_set<Variable*> allVars;
	for (Constraint& c: network.getConstraints()){
		for (Variable* v: c.vars){
			allVars.insert(v);
		}
	}
	// save variable's neighbor to the cache.
	for (Variable* v : allVars){
		neighborCache[v] = network.getNeighborsOfVariable(v);
	}
}

// =====================================================================
// Consistency Checks
// =====================================================================

// Basic consistency check, no propagation done
bool BTSolver::assignmentsCheck ( void )
{
	for ( Constraint c : network.getConstraints() )
		if ( ! c.isConsistent() )
			return false;

	return true;
}

// =================================================================
// Arc Consistency
// =================================================================
bool BTSolver::arcConsistency ( void )
{
    vector<Variable*> toAssign;
    vector<Constraint*> RMC = network.getModifiedConstraints();
    for (int i = 0; i < RMC.size(); ++i)
    {
        vector<Variable*> LV = RMC[i]->vars;
        for (int j = 0; j < LV.size(); ++j)
        {
            if(LV[j]->isAssigned())
            {
                vector<Variable*> Neighbors = network.getNeighborsOfVariable(LV[j]);
                int assignedValue = LV[j]->getAssignment();
                for (int k = 0; k < Neighbors.size(); ++k)
                {
                    Domain D = Neighbors[k]->getDomain();
                    if(D.contains(assignedValue))
                    {
                        if (D.size() == 1)
                            return false;
                        if (D.size() == 2)
                            toAssign.push_back(Neighbors[k]);
                        trail->push(Neighbors[k]);
                        Neighbors[k]->removeValueFromDomain(assignedValue);
                    }
                }
            }
        }
    }
    if (!toAssign.empty())
    {
        for (int i = 0; i < toAssign.size(); ++i)
        {
            Domain D = toAssign[i]->getDomain();
            vector<int> assign = D.getValues();
            trail->push(toAssign[i]);
            toAssign[i]->assignValue(assign[0]);
        }
        return arcConsistency();
    }
    return network.isConsistent();
}

/**
 * Part 1 TODO: Implement the Forward Checking Heuristic
 *
 * This function will do both Constraint Propagation and check
 * the consistency of the network
 *
 * (1) If a variable is assigned then eliminate that value from
 *     the square's neighbors.
 *
 * Note: remember to trail.push variables before you change their domain
 * Return: a pair of a map and a bool. The map contains the pointers to all MODIFIED variables, mapped to their MODIFIED domain. 
 * 		   The bool is true if assignment is consistent, false otherwise.
 */
pair<unordered_map<Variable*,Domain>,bool> BTSolver::forwardChecking ( void )
{
	unordered_map<Variable*,Domain> modifiedVariables;
	// Optimization :  no need to check assigned value twice or more.
	// eg: editing Cell(1,1) will trigger three constraints, we remove all values assigned on Cell(1,1)
	// out of domain of Cell(1,1)'s neighbor at the first iteration.
	unordered_set<Variable*> processedAssignments;
	// Optimization: incremental propagation with queue
	// Process variables that need propagation( initially from modified constraints)
	// then automatically added when singleton is detected, we assign value to these singleton
	queue<Variable*> propagationQueue;
	unordered_set<Variable*> inQueue;

	vector<Constraint*> RMC = network.getModifiedConstraints();

	for (int i = 0; i < RMC.size(); ++i){
		//  vector of values in that constraint(row/col/cell). 
		vector<Variable*> LV = RMC[i]->vars;

		for (int j = 0; j < LV.size(); ++j){
			if (LV[j]->isAssigned() && processedAssignments.find(LV[j]) == processedAssignments.end()){
				// marked value as checked
				processedAssignments.insert(LV[j]);

				if (inQueue.find(LV[j]) == inQueue.end()){
					propagationQueue.push(LV[j]);
					inQueue.insert(LV[j]);
				}
			}
		}
	}
	while (!propagationQueue.empty()){
			Variable* assignedVar = propagationQueue.front();
			propagationQueue.pop();
			inQueue.erase(assignedVar);

			if (!assignedVar->isAssigned()) continue;

			int assignedValue = assignedVar->getAssignment();
			// search neighbors using cache
			vector<Variable*>& Neighbors = neighborCache[assignedVar];

			for (int k = 0; k < Neighbors.size(); ++k){
				// Only process unassigned neighbors
				if (!Neighbors[k]->isAssigned()){
					const Domain& D = Neighbors[k]->getDomain();
						
					// If neighbor's domain contains the assigned value,
					// remove it from its domain. 
					if (D.contains(assignedValue)){
						// Optimization: Check if the domain will be empty,early return
						if (D.size() == 1)
							return make_pair(modifiedVariables,false);

						// push to trail for future backtracking prupose
						trail->push(Neighbors[k]);
						Neighbors[k]->removeValueFromDomain(assignedValue);

						Domain updatedDomain = Neighbors[k]->getDomain();
						modifiedVariables[Neighbors[k]] = updatedDomain;
						
						if (updatedDomain.size() == 0){
							return make_pair(modifiedVariables,false);
						}
						if (updatedDomain.size() == 1 && 
					    	!Neighbors[k]->isAssigned() && 
					    	Neighbors[k]->getDomain().size() == 1) { 
						
							int onlyValue = updatedDomain.getValues()[0];
						
							bool canAssign = true;
							vector<Variable*>& neighborsOfNeighbor = neighborCache[Neighbors[k]];
							for (Variable* nn : neighborsOfNeighbor) {
								if (nn->isAssigned() && nn->getAssignment() == onlyValue) {
									canAssign = false;
									break;
								}
							}
						
							if (!canAssign) {
								return make_pair(modifiedVariables, false);
							}

							trail->push(Neighbors[k]);
							Neighbors[k]->assignValue(onlyValue);

							if (inQueue.find(Neighbors[k]) == inQueue.end()){
								propagationQueue.push(Neighbors[k]);
								inQueue.insert(Neighbors[k]);
							}
						}
					}
				}
			}
		}
	return make_pair(modifiedVariables,true);
}

/**
 * Part 2 TODO: Implement both of Norvig's Heuristics
 *
 * This function will do both Constraint Propagation and check
 * the consistency of the network
 *
 * (1) If a variable is assigned then eliminate that value from
 *     the square's neighbors.
 *
 * (2) If a constraint has only one possible place for a value
 *     then put the value there.
 *
 * Note: remember to trail.push variables before you change their domain
 * Return: a pair of a map and a bool. The map contains the pointers to all variables that were assigned during 
 *         the whole NorvigCheck propagation, and mapped to the values that they were assigned. 
 *         The bool is true if assignment is consistent, false otherwise.
 */
pair<unordered_map<Variable*,int>,bool> BTSolver::norvigCheck ( void )
{
    return make_pair(unordered_map<Variable*, int>(), false);
}

/**
 * Optional TODO: Implement your own advanced Constraint Propagation
 *
 * Completing the three tourn heuristic will automatically enter
 * your program into a tournament.
 */
bool BTSolver::getTournCC ( void )
{
	return false;
}

// =====================================================================
// Variable Selectors
// =====================================================================

// Basic variable selector, returns first unassigned variable
Variable* BTSolver::getfirstUnassignedVariable ( void )
{
	for ( Variable* v : network.getVariables() )
		if ( !(v->isAssigned()) )
			return v;

	// Everything is assigned
	return nullptr;
}

/**
 * Part 1 TODO: Implement the Minimum Remaining Value Heuristic
 *
 * Return: The unassigned variable with the smallest domain
 */
Variable* BTSolver::getMRV ( void )
{
    Variable* best = nullptr;
    int smallestDomainSize = INT_MAX;

    for (Variable* v : network.getVariables())
    {
        if (!v->isAssigned())
        {
            int domainSize = v->getDomain().size();

            if (domainSize < smallestDomainSize)
            {
                smallestDomainSize = domainSize;
                best = v;
            }
        }
    }

    return best;
}



/**
 * Part 2 TODO: Implement the Minimum Remaining Value Heuristic
 *                with Degree Heuristic as a Tie Breaker
 *
 * Return: The unassigned variable with the smallest domain and affecting the most unassigned neighbors.
 * 		   If there are multiple variables that have the same smallest domain with the same number 
 * 		   of unassigned neighbors, add them to the vector of Variables.
 *         If there is only one variable, return the vector of size 1 containing that variable.
 */
vector<Variable*> BTSolver::MRVwithTieBreaker ( void )
{
	vector<Variable*> result;
	int smallestDomainSize = INT_MAX;
	int mostConstraints = -1;

	for (Variable* v: network.getVariables())
	{
		if (!v->isAssigned()){
			int domainSize = v->getDomain().size();
			// found a smaller domain, reset the constraint
			if (domainSize < smallestDomainSize){
				smallestDomainSize = domainSize;
				mostConstraints = -1;
				result.clear();
			}
			// only node with smaller domain could enter here
			if (domainSize == smallestDomainSize){
				int degree = 0;
				for (Variable* neighbor: neighborCache[v]){
					if (!neighbor->isAssigned())
						degree++;
				}
			// found 
			if (degree > mostConstraints){
				mostConstraints = degree;
				result.clear();
				result.push_back(v);
			}
			else if (degree == mostConstraints){
				result.push_back(v);
			}
		  }
		}
	}
    return result;
}

/**
 * Optional TODO: Implement your own advanced Variable Heuristic
 *
 * Completing the three tourn heuristic will automatically enter
 * your program into a tournament.
 */
Variable* BTSolver::getTournVar ( void )
{
	return nullptr;
}

// =====================================================================
// Value Selectors
// =====================================================================

// Default Value Ordering
vector<int> BTSolver::getValuesInOrder ( Variable* v )
{
	vector<int> values = v->getDomain().getValues();
	sort( values.begin(), values.end() );
	return values;
}

/**
 * Part 1 TODO: Implement the Least Constraining Value Heuristic
 *
 * The Least constraining value is the one that will knock the least
 * values out of it's neighbors domain.
 *
 * Return: A list of v's domain sorted by the LCV heuristic
 *         The LCV is first and the MCV is last
 */
vector<int> BTSolver::getValuesLCVOrder ( Variable* v )
{
    vector<int> values = v->getDomain().getValues();
    vector<Variable*>& neighbors = neighborCache[v];

    unordered_map<int, int> elimCount;
    for (int val : values)
        for (Variable* neighbor : neighbors)
            if (!neighbor->isAssigned() && neighbor->getDomain().contains(val))
                elimCount[val]++;

    sort(values.begin(), values.end(), [&](int a, int b) {
        return elimCount[a] < elimCount[b];
    });

    return values;
}

/**
 * Optional TODO: Implement your own advanced Value Heuristic
 *
 * Completing the three tourn heuristic will automatically enter
 * your program into a tournament.
 */
vector<int> BTSolver::getTournVal ( Variable* v )
{
	return vector<int>();
}

// =====================================================================
// Engine Functions
// =====================================================================

int BTSolver::solve ( float time_left)
{
	if (time_left <= 60.0)
		return -1;
	double elapsed_time = 0.0;
    clock_t begin_clock = clock();

	if ( hasSolution )
		return 0;

	// Variable Selection
	Variable* v = selectNextVariable();

	if ( v == nullptr )
	{
		for ( Variable* var : network.getVariables() )
		{
			// If all variables haven't been assigned
			if ( ! ( var->isAssigned() ) )
			{
				return 0;
			}
		}

		// Success
		hasSolution = true;
		return 0;
	}

	// Attempt to assign a value
	for ( int i : getNextValues( v ) )
	{
		// Store place in trail and push variable's state on trail
		trail->placeTrailMarker();
		trail->push( v );

		// Assign the value
		v->assignValue( i );

		// Propagate constraints, check consistency, recurse
		if ( checkConsistency() ) {
			clock_t end_clock = clock();
			elapsed_time += (float)(end_clock - begin_clock)/ CLOCKS_PER_SEC;
			double new_start_time = time_left - elapsed_time;
			int check_status = solve(new_start_time);
			if(check_status == -1) {
			    return -1;
			}
			
		}

		// If this assignment succeeded, return
		if ( hasSolution )
			return 0;

		// Otherwise backtrack
		trail->undo();
	}
	return 0;
}

bool BTSolver::checkConsistency ( void )
{
	if ( cChecks == "forwardChecking" )
		return forwardChecking().second;

	if ( cChecks == "norvigCheck" )
		return norvigCheck().second;

	if ( cChecks == "tournCC" )
		return getTournCC();

	return assignmentsCheck();
}

Variable* BTSolver::selectNextVariable ( void )
{
	if ( varHeuristics == "MinimumRemainingValue" )
		return getMRV();

	if ( varHeuristics == "MRVwithTieBreaker" )
		return MRVwithTieBreaker()[0];

	if ( varHeuristics == "tournVar" )
		return getTournVar();

	return getfirstUnassignedVariable();
}

vector<int> BTSolver::getNextValues ( Variable* v )
{
	if ( valHeuristics == "LeastConstrainingValue" )
		return getValuesLCVOrder( v );

	if ( valHeuristics == "tournVal" )
		return getTournVal( v );

	return getValuesInOrder( v );
}

bool BTSolver::haveSolution ( void )
{
	return hasSolution;
}

SudokuBoard BTSolver::getSolution ( void )
{
	return network.toSudokuBoard ( sudokuGrid.get_p(), sudokuGrid.get_q() );
}

ConstraintNetwork BTSolver::getNetwork ( void )
{
	return network;
}
